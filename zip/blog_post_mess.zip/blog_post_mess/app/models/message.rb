class Message < ActiveRecord::Base
  belongs_to :post
  validates :author, :message, presence: true
  validates :message, length: { maximum: 1000 }
end
