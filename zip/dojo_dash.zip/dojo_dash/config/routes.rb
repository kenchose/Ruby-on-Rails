Rails.application.routes.draw do
  get 'dojos' => 'dojos#dojos'
end
