class TimesController < ApplicationController
	def main
		@time = Time.now.strftime("%I:%M %p")
		@date = Date.today.strftime("%A %b %d")
	end

end
