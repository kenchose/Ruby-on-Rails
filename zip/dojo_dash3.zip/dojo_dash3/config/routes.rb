Rails.application.routes.draw do
  resources :dojos
  # get 'dojos' => 'dojos#index'

  # get 'dojos/new' => 'dojos#new'

  # post 'dojos/create' => 'dojos#create'

  # get 'dojos/show'

  # get 'dojos/edit'

  # get 'dojos/update'

  # get 'dojos/destroy'

end
